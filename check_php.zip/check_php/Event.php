<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Events & Class</title>
	<link rel="stylesheet" href="stylesheet.css">
</head>

<body>	
<div class="header">
<img src="Images/The Kitchen.png" style="width:15%" alt=""/>
<h1>The Kitchen Cooking Studio</h1>
</div>

<div class="navbar">
  <a href="Home.php">Home</a>
  <div class="dropdown">
    <button class="dropbtn">Recipes 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Recipe-Main Dishes.php">Main Dish</a>
      <a href="Recipe-Salad.php">Salad</a>
      <a href="Recipe-Healthy Drink.php">Drink</a>
    </div>
  </div>
  <a href="Event.php">Events & Class</a>
  <a href="About Us.php">About Us</a>
</div>

<div class="card">
	<div class="slideshow-container">

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 1.png" style="width:100%" alt=""/>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 2.png" style="width:100%" alt=""/>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 3.png" style="width:100%" alt=""/>
	</div>

	</div>
	<br>

	<div style="text-align:center">
  		<span class="dot"></span> 
  		<span class="dot"></span> 
  		<span class="dot"></span> 
	</div>
    </div>


<!----All the images are taken from https://www.canva.com/------>
	<h1>Events</h1>	 
	<div class="row">
		<div class="col-3">
			<br><br><br> <center><img src="Images/Event 1.PNG" style="width: 340px; height: 300px;" alt=""/></center><br>
			<center><br><h2>Yummy & Healthy - Main Dishes Cooking Lesson</h2><br></center>
			<center><p style="text-align: center">Face problems on preparing <br> healthy & yummy main dishes for you & your love ones?
				 <br> No worries!<br> Join & learn from our professional chef in <br>Yummy & Healthy - Main Dishes Cooking Lesson</p></center><br>
			  <center><p><b>Price:</b><br>RM150/pax (1 month)</p></center> 
			  <center><p><b>Time:</b><br>Friday, Saturday & Sunday (5:00p.m. to 7:00p.m.)</p></center> 
			  <center><p><b>Other Details:</b><br></center> 
				<table border = "1" width = "340px" align = "center" bgcolor = "white">
				<tr>
				<td>
				<ul>
				<li>All cooking equipments & ingredients are well prepared.</li>
				<li>Reserved parking space for each participant.</li>
				<li>Free 1 set apron, hand gloves & chef hat given to each participant.</li>
				<li>Feel free to take away & share your dishes with love ones.</li>
				<li>Only 8 classes offered (1 class per week)</li>
				<li>At least 8 main dishe recipes will be promote to participant</li>
				<li>Register online</li>
				</ul>
				</td>
				</tr>
				</table>
				</p>
				<center>
				<a href="RegisterForm.php">
				<button class="button button1">Register Now
			 	</button></a>
				</center><br><br><br>
		</div>
		</div>
	</div>

<div class="row">
		<div class="col-3">
			<br><br><br> <center><img src="Images/Event 2.PNG" style="width: 340px; height: 300px;" alt=""/></center><br>
			<center><br><h2>Bake with Emily - Healthy Pastries Baking Lesson</h2><br></center>
			<p style="text-align: center">"Who says dessert & pastries are unhealthy?"<br> Hurry! meet with our professional baker.<br> Make healthy dessert & pastries with love.<br>Eat Healthy, Share The Love.</p><br>
			  <center><p><b>Price:</b><br>RM120/pax (1 month)</p></center> 
			  <center><p><b>Time:</b><br>Saturday & Sunday (1:00p.m. to 4:00p.m.)</p></center> 
			  <center><p><b>Other Details:</b><br></center> 
				<table border = "1" width = "340px" align = "center" bgcolor = "white">
				<tr>
				<td>
				<ul>
				<li>All cooking equipments & ingredients are well prepared.</li>
				<li>Reserved parking space for each participant.</li>
				<li>Free 1 set apron, hand gloves & chef hat given to each participant.</li>
				<li>Feel free to take away & share your pastries & desserts with love ones.</li>
				<li>Only 4 classes offered (1 class per week)</li>
				<li>At least 4 pastry recipes will be promote to participant</li>
				<li>Register online</li>
				</ul>
				</td>
				</tr>
				</table>
				</p>
				<center>
				<a href="RegisterForm.php">
				<button class="button button1">Register Now
			 	</button></a>
				</center><br><br><br>
		</div>
		</div>
	</div>
	
<div class="row">
		<div class="col-3">
			<br><br><br> <center><img src="Images/Event 3.PNG" style="width: 340px; height: 300px;" alt=""/></center><br>
			<center><br><h2>Eat Colourful - Salad Making Lesson</h2><br></center>
			<p style="text-align: center">Feel boring with normal salad?<br>Looking for colourful & new salad recipe?<br> Here you are! <br>
				You are welcome to join us in <br> Eat Colourful - Salad Making Lesson</p><br>
			  <center><p><b>Price:</b><br>RM180/pax (1 month)</p></center> 
			  <center><p><b>Time:</b><br>Saturday & Sunday (9a.m. to 11a.m.)</p></center> 
			  <center><p><b>Other Details:</b><br></center> 
				<table border = "1" width = "340px" align = "center" bgcolor = "white">
				<tr>
				<td>
				<ul>
				<li>All cooking equipments & ingredients are well prepared.</li>
				<li>Reserved parking space for each participant.</li>
				<li>Free 1 set apron, hand gloves & chef hat given to each participant.</li>
				<li>Feel free to take away & share your salads with love ones.</li>
				<li>Only 4 classes offered (1 class per week)</li>
				<li>At least 10 salad recipes will be promote to participant</li>
				<li>Register online</li>
				</ul>
				</td>
				</tr>
				</table>
				</p>
				<center>
				<a href="RegisterForm.php">
				<button class="button button1">Register Now
			 	</button></a>
				</center><br><br><br>
		</div>
		</div>
	</div>

<div class="row">
		<div class="col-3">
			<br><br><br> <center><img src="Images/Coming soon.png" style="width: 340px; height: 300px;" alt=""/></center><br>
			<center><br><h2>Events and Activities Coming Soon</h2><br></center>
			<p style="text-align: center">Interested with our events and activities?<br>We had prepared more for you.<br> Stay Tune! </p><br>
			  <center><p><b>Events & Activities Coming Soon:</b><br></center> 
				<table border = "1" width = "340px" align = "center" bgcolor = "white">
				<tr>
				<td>
				<ul>
				<li>Talk - "How Healthy Eating Affects Your Life?"</li>
				<li>Crispy & Healthy - Healthy Cookies Baking Lesson</li>
				<li>Make Colourful Drinks! - Healthy Drinks Making Lesson</li>
				<li>Healthy Salad Making Competition</li>
				</ul>
				</td>
				</tr>
				</table>
				</p>
				<br><br><br>
		</div>
		</div>
	
	<div class="row">
		 <div class="col-3">
			 <br><br><h2><center>Meet Our Professional Tutor</center></h2><br>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Tutor 1.PNG" style="width:60%" alt=""/>
				 <p><center><b>Chef Simon Martin</b></center><br> Graduated from Le Cordon Bleu <br> Former chef in 5 stars hotel <br> Champion owner for many chef competition<br> Chef experience: 5 years</p>
				 </center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/tutor 2.PNG" style="width:60%" alt=""/>
				 <p><center><b>Baker Olivia Lee</b></center><br>Graduated from MIB Collage (Institute for Baking) <br> Best Pastry Awards owner in year 2020 <br> Baking experience: 3 years</p>
				 </center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/tutor 3.PNG" style="width:60%" alt=""/>
				 <p><center><b>Chef Muhammad Ismail Bin Haikal</b></center><br>Graduated from The Academy of Pastry Arts Malaysia <br> (APCA Malaysia) <br> Lecturer in APCA <br> Teaching experience: 8 years</p>
				 </center><br>
			 </div>
			 <center>
				<a href="About Us.php">
				<button class="button button1">Know More About Us
			 	</button></a>
				</center>
			 <br><br>
		 </div>
    </div>
	
	<br><br>


<div class="footer">
  <h2>Contact Us</h2>
	<table style="width: 100%">
		<tr>
			<td style="width:50%">
				<p><b>The Kitchen Cooking Studio</b></p>
				<p>Address: <br>123, Jalan ABC, <br>Gateway Batu Pahat,<br>83000 Batu Pahat, Johor, Malaysia. </p>
				<p>Contact Number:<br>+607-123 4567</p>
				<a href= "About Us.php">FAQ</a><br>
				<a href="Event.php">More Events</a>
				<p>Website QR:</p>
				<img src="Images/qrcode.png" style="width:90px; height:120px;" alt=""/>
			</td>
			<td>
				<p>Factulty of Computer Science & Information technology <br> University Tun Hussein Onn Malaysia</p>
				<p>BIC 21203 Web Development<br>Group Project</p>
				<p>Lee Zi Hui (AI190244)<br>Liew Jia Yu (AI190235)<br>Sim Shin Ying (AI190231)<br>Tan Qian Ying (AI190236)</p>
			</td>
		</tr>
	</table>
	
</div>



<!--script for slideshow*/-->
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 5 seconds
}
</script>
	
</body>
</html>
