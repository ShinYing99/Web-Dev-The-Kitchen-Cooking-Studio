<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home</title>
	<link rel="stylesheet" href="stylesheet.css">
	<script>alert("Welcome to The Kitchen Cooking Studio Website")</script>
</head>
<body>
<div class="header">
  <img src="Images/The Kitchen.png" style="width:25%" alt=""/>
  <h1>The Kitchen Cooking Studio</h1>
</div>

<div class="navbar">
  <a href="Home.php">Home</a>
  <div class="dropdown">
    <button class="dropbtn">Recipes
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Recipe-Main Dishes.php">Main Dish</a>
      <a href="Recipe-Salad.php">Salad</a>
      <a href="Recipe-Healthy Drink.php">Drink</a>
    </div>
  </div>
  <a href="Event.php">Events & Class</a>
  <a href="About Us.php">About Us</a>
</div><br>

<div class="card">
	<div class="slideshow-container">

	<br><div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 1.png" style="width:100%" alt=""/>
  	<div class="text"></div>
	</div>

	<br><div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 2.png" style="width:100%" alt=""/>
  	<div class="text"></div>
	</div>

	<br><div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 3.png" style="width:100%" alt=""/>
  	<div class="text"></div>
	</div>

	</div>
	<br><br>

	<div style="text-align:center">
  		<span class="dot"></span> 
  		<span class="dot"></span> 
  		<span class="dot"></span> 
	</div>
    </div>
	
<!--------All images and recipes are taken from https://www.eatingwell.com/recipes/18421/low-calorie/main-dish/ & https://www.eatingwell.com/recipes/18430/low-calorie/drinks/--------->
	
	<br><br><div class="row">
		 <div class="col-3">
			 <br><br><h2><center>Healthy Main Dish Recipes</center></h2><br>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Main Dish 1.PNG" style="width:60%" alt=""/>
				  <p><center>One-Pot Greek Pasta</center></p>
				 </center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Main Dish 4.PNG" style="width:60%" alt=""/>
				  <p><center>Salmon with Asparagus and Mushrooms</center></p>
				 </center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Main Dish 5.PNG" style="width:60%" alt=""/>
				  <p><center>Slow-Cooker Braised Beef with Carrots and Turnips</center></p>
				 </center><br>
			 </div>
			 <center>
				 <a href="Recipe-Main Dishes.php">
				 <button class="button button1">Read More
			 </button></a>
			 </center><br><br>
		 </div>
    </div>
	
	<div class="row">
		 <div class="col-3">
			 <br><br><h2><center>Healthy Salad Recipes</center></h2><br>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Salad 1.PNG" style="width:60%" alt=""/>
				  <p><center>Buffalo Chicken Salad</center></p>
				</center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Salad 2.PNG" style="width:60%" alt=""/>
				  <p><center>Shrimp, Avocado, and Egg Chopped Salad</center></p>
				 </center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Salad 6.PNG" style="width:60%" alt=""/>
				  <p><center>Chicken Caesar Pasta Salad</center></p>
				 </center><br>
			 </div>
			 <center>
				 <a href="Recipe-Salad.php">
				 <button class="button button1">Read More
			 </button></a>
			 </center><br><br>
		 </div>
    </div>
	
	<div class="row">
		 <div class="col-3">
			 <br><br><h2><center>Healthy Drink Recipes</center></h2><br>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Drink 1.PNG" style="width:60%" alt=""/>
				  <p><center>Blueberry-Cranberry Smoothie</center></p>
				</center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Drink 4.PNG" style="width:60%" alt=""/>
				  <p><center>Healthy Hot Chocolate</center></p>
				 </center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Drink 3.PNG" style="width:60%" alt=""/>
				  <p><center>Berry-Almond Smoothie Bowl</center></p>
				 </center><br>
			 </div>
			 <center>
				 <a href="Recipe-Healthy Drink.php">
				 <button class="button button1">Read More
			 </button></a>
			 </center><br><br>
		 </div>
    </div>
	

	
<div class="card">
	<!--Images taken from website: https://intermountainhealthcare.org/blogs/topics/live-well/2017/03/eating-right-change-the-foods-change-your-life/-->
	<img src="Images/EATING RIGHT CHANGE THE FOOD CHANGE YOUR LIFE.png" width="100%" alt="Blog">
	</div><br><br>
	
	<div class="card">
	<p><h2><center>A Healthy Diet, A Healthier World By World Health Organisation (WHO)</center></h2></p>
	<!--video taken form WHO Official Youtube : https://www.youtube.com/watch?v=XMcab1MFaLc-->
	<center><video width="70%" controls>
  	<source src="Images/A healthy diet, a healthier world.mp4" type="video/mp4">
	</video></center>
	</div><br><br>
	
<!--------All images are taken from https://www.canva.com/--------->
	 <div class="row">
		 <div class="col-3">
			 <br><br><h2><center>Events</center></h2><br>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Event 1.PNG" style="width:90%" alt=""/>
				  <p><center>Yummy & Healthy - Main Dishes Cooking Lesson</center></p>
				</center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Event 2.PNG" style="width:90%" alt=""/>
				  <p><center>Bake with Emily - Healthy Pastries Baking Lesson</center></p>
				 </center>
			 </div>
			 <div class="leftcard">
			 <center>
				 <img src="Images/Event 3.PNG" style="width:90%" alt=""/>
				  <p><center>Eat Colourful - Salad Making Lesson</center></p>
				 </center><br>
			 </div>
			 <center>
				 <a href="Event.php">
				 <button class="button button1">Read More
			 </button></a>
			 </center><br><br>
		 </div>
    </div>
	
	<div class="card">
		<br>
				<img src="Images/Register.png" alt="Register">
			 	<br><a href="RegisterForm.php">
				<center><button class="btn">Register Now</button></a></center>
		<br>
		</div>
		
	
<div class="footer">
  <h2>Contact Us</h2>
	<table style="width: 100%">
		<tr>
			<td style="width:50%">
				<p><b>The Kitchen Cooking Studio</b></p>
				<p>Address: <br>123, Jalan ABC, <br>Gateway Batu Pahat,<br>83000 Batu Pahat, Johor, Malaysia. </p>
				<p>Contact Number:<br>+607-123 4567</p>
				<a href= "About Us.php">FAQ</a><br>
				<a href="Event.php">More Events</a>
				<p>Website QR:</p>
				<img src="Images/qrcode.png" style="width:90px; height:120px;" alt=""/>
			</td>
			<td>
				<p>Factulty of Computer Science & Information technology <br> University Tun Hussein Onn Malaysia</p>
				<p>BIC 21203 Web Development<br>Group Project</p>
				<p>Lee Zi Hui (AI190244)<br>Liew Jia Yu (AI190235)<br>Sim Shin Ying (AI190231)<br>Tan Qian Ying (AI190236)</p>
			</td>
		</tr>
	</table>
	
</div>

	
<!--script for slideshow*/-->
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 5 seconds
}
</script>

</body>
</html>


