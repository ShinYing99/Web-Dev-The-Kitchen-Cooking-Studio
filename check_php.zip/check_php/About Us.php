<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us</title>
	<link rel="stylesheet" href="stylesheet.css">
</head>
<body>

<div class="header">
  <img src="Web Development Project/Images/The Kitchen.png" style="width:15%" alt=""/>
  <h1>The Kitchen Cooking Studio</h1>
</div>

<div class="navbar">
  <a href="Home.php">Home</a>
  <div class="dropdown">
    <button class="dropbtn">Recipes
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Recipe-Main Dishes.php">Main Dish</a>
      <a href="Recipe-Salad.php">Salad</a>
      <a href="Recipe-Healthy Drink.php">Drink</a>
    </div>
  </div>
  <a href="Event.php">Events &  Class</a>
  <a href="About Us.php">About Us</a>
</div>

<div class="card">
	<div class="slideshow-container">

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Web Development Project/Images/Healthy 1.png" style="width:100%" alt=""/>
  	<div class="text"></div>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Web Development Project/Images/Healthy 2.png" style="width:100%" alt=""/>
  	<div class="text"></div>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Web Development Project/Images/Healthy 3.png" style="width:100%" alt=""/>
  	<div class="text"></div>
	</div>

	</div>
	<br>

	<div style="text-align:center">
  		<span class="dot"></span> 
  		<span class="dot"></span> 
  		<span class="dot"></span> 
	</div>
    </div>
	
<!--------All images and recipes are taken from https://www.eatingwell.com/recipes/18421/low-calorie/main-dish/ & https://www.eatingwell.com/recipes/18430/low-calorie/drinks/--------->
	<h1>About Us</h1>
	 <div class="row">
		 <div class="col-3">
			 <center>
				 <br><br><img src="Web Development Project/Images/Healthy 4.png" style="width:60%" alt=""/>
				 <br><br> <p><center><b>We care about your health.</b><br>The Kitchen Cooking Studio is establish in year 2021.<br>A busy life leads to negligence of one's own diet and health <br> We concern about the public's health and promote the correct and healthy eating ways to the public.<br> Events and activities offered encourage more people concern about their eating habit.<br> Delicious and healthy recipe with short duration ready for you. <br>Eat Healthy, Live Wonderful! </center></p><br><br>
			</center>
		 </div>
    </div>
	
	<div class="row">
		 <div class="col-3">
			 <center>
				 <br><br><img src="Web Development Project/Images/Healthy 5.png" style="width:60%" alt=""/>
				 <br><br> <p><center><b>Who says: "Delicious can't be Healthy?"</b><br>We concern about your eating habit.<br> Delicious, healthy and easy made recipes ready for you.<br>Eat Healthy, Live Wonderful! </center></p><br><br>
			</center>
			 <center>
				 <a href="Recipe-Main Dishes.php">
				 <button class="button button1">Read More
			 </button></a>
			 </center><br><br>
		 </div>
    </div>
	
	
	<div class="row">
		 <div class="col-3">
			 <center>
				 <br><br><img src="Web Development Project/Images/Healthy 6.png" style="width:60%" alt=""/>
				 <br><br> <p><center><b>Don't know where to start for healthy meals?</b><br>We concern about the consumption of nutritions in every meal you have. <br> Fun and relaxing cooking classes ready for you. <br> Come and join us. <br>Eat Healthy, Live Wonderful! </center></p><br><br>
			</center>
			 <center>
				 <a href="Event.php">
				 <button class="button button1">Read More
			 </button></a>
			 </center><br><br>
		 </div>
    </div>
	

	
<div class="card">
	<!--https://intermountainhealthcare.org/blogs/topics/live-well/2017/03/eating-right-change-the-foods-change-your-life/-->
	<img src="Web Development Project/Images/Healthy 7.PNG" width="100%" alt="Blog">
	</div>

	
<!--------All images and recipes are taken from https://www.canva.com/--------->
	
	<div class="row">
		 <div class="col-3">
			 <br><center><h2>The Environment</h2></center><br>
			 <center><p>We know environemnt is the key of learning.<br> We do our best to provide you comfortable and relaxed learning environment.</p></center>
			 <center>
				 <br><br><img src="Web Development Project/Images/Service 1.png" style="width:60%" alt=""/><br><br>
			</center>
			 <center>
				 <br><br><img src="Web Development Project/Images/Service 2.png" style="width:60%" alt=""/><br><br>
			</center><br><br>
		 </div>
    </div>

<div class="row">
		 <div class="col-3">
			 <br><center><h2>Frequently Asked Questions (FAQ)</h2></center><br>
			 <p style="padding-left: 30px"><b>How to register the class offered?</b></p><br>
			 <ol style="padding-bottom: 30px">
			 <li>Pick the class and day you desired.</li>
			 <li>Fill in the registration form online.</li>
		     <li>Come to our cooking studio on your lesson day for lesson payment.</li>
			 </ol>
		
			 <p style="padding-left: 30px"><b>What do I need to prepare for class?</b></p>
			 <p style="padding-left: 30px">All ingredients and equipments are well prepared.<br> Participants only need to prepare the belongings they need.</p><br>
			
			 <p style="padding-left: 30px"><b>How do I make registration payment?</b></p>
			 <p style="padding-left: 30px">You can make payment when you come to attend your class in our cooking studio.</p>
			 <br>
			 
			 <p style="padding-left: 30px"><b>How many classes in a week?</b></p>
			 <p style="padding-left: 30px">Basically, only one class will be provided for every programme to each participant in a week.</p>
			 <br>
			 
			 <p style="padding-left: 30px"><b>How long will the class conducted?</b></p>
			 <p style="padding-left: 30px">The class will be conducted for a month (4 classes).<br> Different classes will have different time period.</p>
			 <br>
			 
			 <p style="padding-left: 30px"><b>What if there is more than 4 weeks in the month?</b></p>
			 <p style="padding-left: 30px">Lessons will be conducted for 4 weeks (1 class per week). Extra week is not counted.<br></p>
			 <br><br>
			 
		 </div>
    </div>

<div class="footer">
 <h2>Contact Us</h2>
	<table style="width: 100%">
		<tr>
			<td style="width:50%">
				<p><b>The Kitchen Cooking Studio</b></p>
				<p>Address: 123, Jalan ABC, Gateway Batu Pahat,<br>83000 Batu Pahat, Johor, Malaysia. </p>
				<p>Contact Number: +607-123 4567</p>
				<a href="About Us.php">FAQ</a><br>
				<a href="Event.php">More Events</a>
				<p>Website QR:</p>
				<img src="Images/qrcode.png" style="width:90px; height:120px;" alt=""/>
			</td>
			<td>
				<p>Factulty of Computer Science & Information technology<br>University Tun Hussein Onn Malaysia</p>
				<p>BIC 21203 Web Development<br>Project</p>
				<p>Lee Zi Hui (AI190244)<br>Liew Jia Yu (AI190235)<br>Sim Shin Ying (AI190231)<br>Tan Qian Ying (AI190236)</p>
			</td>
		</tr>
	</table>
	
</div>

	
<!--script for slideshow*/-->
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 5 seconds
}
</script>

</body>
</html>


