<!DOCTYPE html>
<html  lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table, td, th {
     border: 1px solid black;
}
	
table {
    width: 100%;
    border-collapse: collapse;
}
* {
  	box-sizing: border-box;
}

.header {
  	background-image: url("Images/header.png");
  	padding: 20px;
  	text-align: center;
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 33.33%;
    padding: 10px;
}
/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}
	
input[type=text], input[type=number], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}
	
button {
    background-color: lightgray;
    color: black;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
	
input[type=button]:hover {
    background-color: white;
}
	
input[type=button] {
    background-color: cornflowerblue;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
	
input[type=button]:hover {
    background-color: lightblue;
}
		
input.larger {
        transform: scale(1.3);
        margin: 20px;
		}
		

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
}
	
h1 {
    text-align: center;
    font-size: 50px;
    color: black;
    font-weight: bold;
	background-color: lightgray;
}
	
h4 {
    text-align: center;
    color: blue;
}

label {
    font-weight: bold;
}

#myForm div{
    margin-bottom:15px;
}

body{
	background-image: url("Images/background.png");
}
	
.error {
  color: #FF0000;
  font-weight: bold;
}


/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
.column {
width: 100%;
}
}
</style>
</head>
<body>
	
<?php
	error_reporting(0);
	session_start();
	
        // servername => localhost
		// username => root
		// password => empty
		// database name => webdatabse
		$conn = mysqli_connect("localhost", "root", "", "webdatabase");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
	    //define variables
		$name_err = $name_err2 = $gender_err = $age_err = $age_err2 = $phone_err =$phone_err2 = $email_err =$email_err2 = $classes_err ="";
	
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
		
        //define variables
        $name = $_POST['name'];
        $gender = $_POST['gender'];
        $age = $_POST['age'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
		$aclasses = $_POST['classes'];
			$classes="";
			foreach($aclasses as $classes1)
			{
				$classes .=$classes1.",";
			}
        $note = $_POST['note'];
			
			
        //insert value
			$sql = "INSERT INTO register (name, gender, age, phone, email, classes, note) VALUES ('$name',
			'$gender', '$age', '$phone','$email', '$classes', '$note')";
			
			
        //define variable
		$names = $genders = $ages = $phones = $emails = $classess = $notes="";
		
	    //Validation 
		if(empty($name)) {
			$name_err = "Name is required";
		}else {
			$names = input_data($name);
			
			if (!preg_match ("/^[\p{L} ]+$/u", $name)) {
			$name_err2 = "Only alphabets and whitespace are allowed."; 
			}
		}
		
		if(empty($gender)) {
			$gender_err = "Gender is required";
		}else{
			$genders = input_data($gender);
			
		}
			
		if(empty($age)) {
			$age_err = "Age is required";
		}else {
			$ages = input_data($age);
			
			if ($age > 99 || $age < 0) {
			$age_err2 = "Invalid age";
			}
		}
			
			
		if(empty($phone)) {
			$phone_err = "Phone Number is required";
		}else {
			$phones = input_data($phone);
			
			if ((!preg_match("/^[0-9]*$/", $phone))|| strlen($phone)<10){
			$phone_err2 = "Invalid phone number.";
			}
		} 
			
			
		if(empty($email)) {
			$email_err = "Email is required";
		}else {
			$emails = input_data($email);
			
			if (!preg_match ("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^", $email)) {
			$email_err2 = "Email is not valid";
			}	
		}
		
			
		if(empty($_POST['classes'])) {
			$classes_err = "Must tick at least one";
		}else {
				$classess = input_data($classes);
			
		}
			
			
		if(!empty($note)) {
			$notes = input_data($note);
		}
			
		if($name_err == "" && $name_err2 == "" && $gender_err == "" && $age_err == "" && $age_err2 == "" && $phone_err == "" && $phone_err2 == "" && $email_err == "" && $email_err2 == "" && $classes_err == "") {
			
			
			if(mysqli_query($conn, $sql)){
           echo '<script>alert("Register Successfully.")</script>';
				} 
			else{
            echo "ERROR: Hush! Sorry $sql. "
            . mysqli_error($conn);
        }
		}
		
			
        //Close connection
        mysqli_close($conn);
		}
		function input_data($data) {
  		$data = trim($data);
  		$data = stripslashes($data);
  		$data = htmlspecialchars($data);
  		return $data;
	}
?>
  
  <div class="header">
    <h1>Register Events & Lessons</h1>
  </div>
  <div class="container" style="background-color:white"> 
    
  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <span class="error">*Required</span><br><br>
  <label for="name">Name</label>
	  <span class="error">* <?php echo $name_err;?><br><?php echo $name_err2;?></span>
  <input type="text" name="name" placeholder="Your name">
  <label for="gender">Gender</lable>
	  <span class="error">* <?php echo $gender_err;?></span>
	  <br><br><span style="font-weight: normal;">
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="female">Female </span><br><br>
  <label for="age">Age</label>
	  <span class="error">* <?php echo $age_err;?><br><?php echo $age_err2;?></span>
  <input type="text" id="age" name="age" placeholder="Your age">
  <label for="phoneN">Phone No</label>
	  <span class="error">* <?php echo $phone_err;?><br><?php echo $phone_err2;?></span>
  <input type="text" id="phone" name="phone" placeholder="Your phone no (e.g 0123456789)" maxlength="11">
  <label for="email">Email</label>
	  <span class="error">* <?php echo $email_err;?><br><?php echo $email_err2;?></span>
  <input type="text" id="email" name="email" placeholder="Your Email">
  <label for="package">Lessons</label><span class="error">* <?php echo $classes_err;?></span> <br><br>
	  
	  <label>Yummy & Healthy - Main Dishes Cooking Lesson</label><br>
	  <span style="font-weight: normal; font-size: 13px;">
		<input type="checkbox" class="larger" name="classes[]" value="yh1">YH1- Class1 (Friday 5:00p.m. to 7:00p.m.)<br>
		<input type="checkbox" class="larger" name="classes[]" value="yh2">YH2- Class2 (Saturday 5:00p.m. to 7:00p.m.)<br>
		<input type="checkbox" class="larger" name="classes[]" value="yh3">YH3- Class3 (Sunday 5:00p.m. to 7:00p.m.)<br>
	  </span><br>
	  
	  <label>Bake with Emily - Healthy Pastries Baking Lesson</label><br>
	  <span style="font-weight: normal; font-size: 13px;">
		<input type="checkbox" class="larger" name="classes[]" value="be1">BE1- Class1 (Saturday 1:00p.m. to 4.00p.m.)<br>
		<input type="checkbox" class="larger" name="classes[]" value="be2">BE2- Class2 (Sunday 1:00a.m. to 4:00p.m.)<br>
	  </span><br>
	  
	  <label>Eat Colourful - Salad Making Lesson</label><br>
	  <span style="font-weight: normal; font-size: 13px;">
		<input type="checkbox" class="larger" name="classes[]" value="ec1">EC1- Class1 (Saturday 9:00a.m. to 11.00a.m.)<br>
		<input type="checkbox" class="larger" name="classes[]" value="ec2">EC2- Class2 (Sunday 9:00a.m. to 11:00a.m.)<br>
	  </span><br>
	 
	  <label for="note">Notes</label>
	 <textarea id="note" name="note" placeholder="Write something.." style="height:200px"></textarea>
	  
<p>For more information or any inquiries, please visit to our website through QR code.</p><br>
<img src="Images/qrcode.png" style="width:90px; height:120px;" alt=""/><br><br><br>
<button>Submit</button><br>
</div><br>

</form> 
	
</body>
</html>