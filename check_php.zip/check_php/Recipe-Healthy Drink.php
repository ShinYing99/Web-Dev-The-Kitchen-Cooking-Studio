<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recipes-Healthy Drink</title>
	<link rel="stylesheet" href="stylesheet.css">
</head>

<body>
	
<div class="header">
<img src="Images/The Kitchen.png" style="width:25%" alt=""/>
<h1>The Kitchen Cooking Studio</h1>
</div>

<div class="navbar">
  <a href="Home.php">Home</a>
  <div class="dropdown">
    <button class="dropbtn">Recipes 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Recipe-Main Dishes.php">Main Dish</a>
      <a href="Recipe-Salad.php">Salad</a>
      <a href="Recipe-Healthy Drink.php">Drink</a>
    </div>
  </div>
  <a href="Event.php">Events &  Class</a>
  <a href="About Us.php">About Us</a>
</div>

<div class="card">
	<div class="slideshow-container">

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 1.png" style="width:100%" alt=""/>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 2.png" style="width:100%" alt=""/>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 3.png" style="width:100%" alt=""/>
	</div>

	</div>
	<br>

	<div style="text-align:center">
  		<span class="dot"></span> 
  		<span class="dot"></span> 
  		<span class="dot"></span> 
	</div>
    </div>


<!----All the recipe and images are taken from https://www.eatingwell.com/recipes/18430/low-calorie/drinks/------>
	
	<div>
	<h1>Healthy Drinks</h1>
		<div class="menurow">
			<div class="menucard">
				<div id="drink1">
				<br><br><center><img src="Images/Drink 1.PNG" width="400px" alt=""></center><br><br>
				<center><h1>Blueberry-Cranberry Smoothie</h1></center><br>
				<center><h4>Total Time: 5 minutes</h4></center>
				<center><h4>Servings: 1</h4></center><br>
				<p>Ready to try kefir? We use it in place of yogurt in this healthy smoothie recipe packed with berries and banana.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient1" name="ingredient1" value="mediumbanana">
				<label for="ingredient1">½ frozen medium banana</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient2" name="ingredient2" value="frozenbluberry">
				<label for="ingredient2">1 cup frozen blueberries</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient3" name="ingredient3" value="frozencranberry">
				<label for="ingredient3">½ cup frozen cranberries</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient4" name="ingredient4" value="plainkefir">
				<label for="ingredient4">1 cup low-fat plain kefir </label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Combine banana, blueberries, cranberries and kefir in a blender. Puree until smooth.</li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Low-calories, Low Sodium, Low Fat, Healthy Aging, Healthy Pregnancy,Healthy Heart, High Fiber, High Calcium, Egg Free, Gluten-free, Nut Free, Soy Free, Bone Health  </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "500" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 2 cups</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>245 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>12.5 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>50.4 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>8.0 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>34.3 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>1.3 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>0.2 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>5.0 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>639.0 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>15.7 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>23.1 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>319.4 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>0.6 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>26.7 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>337.4 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>3.1 mg</td>
				</tr>
				<tr>
				<td>Thiamin</td>
				<td>0.1 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn1" onclick="printContent('drink1')">Print Recipe</button></center><br><br>
			</div>
		</div>
	
		<div class="menurow">
			<div class="menucard1">
				<div id="drink2">
				<br><br><center><img src="Images/Drink 2.PNG" width="400px" alt=""></center><br><br>
				<center><h1>Tomato-Vegetable Juice</h1></center><br>
				<center><h4>Total Time: 15 minutes</h4></center>
				<center><h4>Servings: 2</h4></center><br>
				<p>This healthy tomato-vegetable juice recipe contains all the components of a healthy salad, such as lettuce, tomato, bell pepper, celery and carrot, but with less salt than bottled vegetable-blend juices. No juicer? No problem. See the juicing variation below to make this tomato-vegetable juice recipe in a blender.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient9" name="ingredient9" value="romaine">
				<label for="ingredient9">1 cup chopped hearts of romaine</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient10" name="ingredient10" value="chives">
				<label for="ingredient10">¼ cup chopped fresh chives</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient11" name="ingredient11" value="largetomato">
				<label for="ingredient11">2 large tomatoes, cut into wedges</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient12" name="ingredient12" value="jalapeno">
				<label for="ingredient12">¼ fresh jalapeño , stemmed and seeded</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient13" name="ingredient13" value="redbellpepper">
				<label for="ingredient13">1 large red bell pepper, cut into eighths</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient14" name="ingredient14" value="celery">
				<label for="ingredient14">2 large stalks celery, trimmed</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient15" name="ingredient15" value="mediumcarrot">
				<label for="ingredient15">1 medium carrot, peeled</label><br>
				<input type="checkbox"  class="ingredient" id="ingredien16" name="ingredient16" value="icecube">
				<label for="ingredient16">1 cube Ice cubes</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Working in this order, process lettuce, chives, tomatoes, jalapeno, bell pepper, celery and carrot through a juicer according to the manufacturer's directions.</li><br>
				<li>Fill 2 glasses with ice, if desired, and pour the juice into the glasses. Serve immediately.</li><br>
				</ol>
				</p><br>
				
				<p><b>Tips:</b></p>
				<ul>
				<li>No juicer? No problem. Try this DIY version of blended and strained juice instead: Coarsely chop all ingredients. First, place the soft and/or juice ingredients in the blender and process until liquefied. Then, add the remaining ingredients; blend until liquefied. Cut two 24-inch-long pieces of cheesecloth. Completely unfold each piece and then stack the pieces on top of each other. Fold the double stack in half so you have a 4-layer stack of cloth. Line a large bowl with the cheesecloth and pour the contents of the blender into the center. Gather the edges of the cloth together in one hand and use the other hand to twist and squeeze the bundle to extract all the juice from the pulp. Wear a pair of rubber gloves if you don't want the juice to stain your hands.</li>
				</ul><br>
		
				<p><b>Perfect For:</b></p>
				<p>Low Carbohydrate, Low Fat, Dairy-free, Gluten-free, Vegetarian, Vegan, Healthy Immunity, Low Added Sugar </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "500" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: about 8 ounces</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>46 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>1.0 g</td>
				</tr>
				<tr>
				<td>Carbohydrate</td>
				<td>9.0 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>2.0 g</td>
				</tr>
				<tr>
				<td>Sugar</td>
				<td>7.0 g</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>3250.0 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>42.6 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>134.5 mg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>81.8 mg</td>
				</tr>
				<tr>
				<tr>
				<td>Iron</td>
				<td>1.5 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>55.2 mg</td>
				</tr>
				<td>Potassium</td>
				<td>466.0 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>82.0 mg</td>
				</tr>
				<tr>
				<td>Thiamin</td>
				<td>0.2 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn2" onclick="printContent('drink2')">Print Recipe</button></center><br><br>
			</div>
		</div>


		<div class="menurow">
			<div class="menucard">
				<div id="drink3">
				<br><br><center><img src="Images/Drink 3.PNG" width="400px" alt=""></center><br><br>
				<center><h1>Berry-Almond Smoothie Bowl</h1></center><br>
				<center><h4>Total Time: 10 minutes</h4></center>
				<center><h4>Servings: 1</h4></center><br>
				<p>A little frozen banana gives creamy texture to this satisfying smoothie bowl.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient17" name="ingredient17" value="raspberry">
				<label for="ingredient17">⅔ cup frozen raspberries</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient18" name="ingredient18" value="slicedbanana">
				<label for="ingredient18">½ cup frozen sliced bananachopped</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient19" name="ingredient19" value="almondmilk">
				<label for="ingredient19">½ cup plain unsweetened almond milk</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient20" name="ingredient20" value="slicedalmond">
				<label for="ingredient20">5 tablespoons sliced almonds, divided</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient21" name="ingredient21" value="groudcinnamon">
				<label for="ingredient21">¼ teaspoon ground cinnamon</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient22" name="ingredient22" value="groundcardamon">
				<label for="ingredient22">⅛ teaspoon ground cardamom</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient23" name="ingredient23" value="vallina">
				<label for="ingredient23">⅛ teaspoon vanilla extract</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient24" name="ingredient24" value="blueberry">
				<label for="ingredient24">¼ cup blueberries</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient25" name="ingredient25" value="coconutflake">
				<label for="ingredient25">1 tablespoon unsweetened coconut flakes</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Blend raspberries, banana, almond milk, 3 tablespoons almonds, cinnamon, cardamom and vanilla in a blender until very smooth.</li><br>
				<li>Pour the smoothie into a bowl and top with blueberries, the remaining 2 tablespoons almonds and coconut.</li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Heart Healthy, Low-calories, High Fiber, Dairy-free, Diabetes Appropriate, Egg Free, Gluten-free, Vegetarian, Vegan, Low Sodium, High Blood Pressure, High Calcium, Soy Free, Bone Health, Healthy Aging, Healthy Immunity, Healthy Pregnancy, Low Added Sugar</p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "500" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 1 1/3 cups</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>360 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>9.2 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>45.6 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>14.0 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>21.4 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>19.0 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>3.3 g</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>357.7 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>35.6 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>52.0 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>341.0 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>2.5 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>129.0 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>736.2 mg</td>
				</tr>
				<tr>
				<td>Sodim</td>
				<td>89.4 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn1" onclick="printContent('drink3')">Print Recipe</button></center><br><br>
			</div>
		</div>

		<div class="menurow">
			<div class="menucard1">
				<div id="drink4">
				<br><br><center><img src="Images/Drink 4.PNG" width="400px" alt=""></center><br><br>
				<center><h1>Healthy Hot Chocolate</h1></center><br>
				<center><h4>Total Time: 5 minutes</h4></center>
				<center><h4>Servings: 1</h4></center><br>
				<p>This healthier cup of hot chocolate uses low-fat milk, natural cocoa powder and just enough sugar to sweeten things up without going overboard on calories. As an added bonus, the milk provides a healthy serving of protein and calcium, which you won't get from sugar-loaded powdered hot-chocolate mixes prepared using water. Spice it up with an add-in like orange zest, cinnamon or vanilla for a delicious twist on this classic treat.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient5" name="ingredient5" value="cocoapowder">
				<label for="ingredient5">1 tablespoon natural, unsweetened cocoa powder</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient6" name="ingredient6" value="sugar">
				<label for="ingredient6">1 tablespoon sugar</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient7" name="ingredient7" value="lowfatmilk">
				<label for="ingredient7">1 cup low-fat milk, warmed to steaming</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient8" name="ingredient8" value="gratedcarrot">
				<label for="ingredient8">Add-ins like orange zest and ground cloves; ground cardamom and vanilla extract; or chili powder and ground cinnamon (optional)</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Combine cocoa powder and sugar in a mug; swirl in warmed milk. Add in one of the flavor additions, if desired.</li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Vegetarian, Egg Free, Low Sodium, Low-calories, Dairy-free, Gluten-free, Nut Free </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "500" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 1 cup</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>164 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>0.3 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>27.9 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>2.0 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>24.8 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>3.1 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>1.0 g</td>
				</tr>
				<tr>
				<tr>
				<td>Cholesterol</td>
				<td>12.2 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>478.2 IU</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>13.9 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>312.0 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>12.2 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>53.7 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>448.2 mg</td>
				</tr>
				<td>Sodium</td>
				<td>108.6 mg</td>
				</tr>
				<tr>
				<td>Thiamin</td>
				<td>0.1 mg</td>
				</tr>
				<tr>
				<td>Added sugar</td>
				<td>13 g</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn2" onclick="printContent('drink4')">Print Recipe</button></center><br><br>
			</div>
		</div>
	
	<div class="menurow">
			<div class="menucard">
				<div id="drink5">
				<br><br><center><img src="Images/Drink 5.PNG" width="400px" alt=""></center><br><br>
				<center><h1>Pumpkin-Spice Hot Toddy</h1></center><br>
				<center><h4>Total Time: 5 minutes</h4></center>
				<center><h4>Servings: 1</h4></center><br>
				<p>Flavored decaf tea adds a seasonal twist to a traditional hot toddy recipe. You can use any flavor of tea for this easy cocktail, but we love the comforting notes of pumpkin-spice in the fall and winter.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient26" name="ingredient26" value="pumpkinspicetea">
				<label for="ingredient26">6 ounces brewed decaf pumpkin-spice tea or other decaf or herbal tea</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient27" name="ingredient27" value="bourbon">
				<label for="ingredient27">1 ounce bourbon</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient28" name="ingredient28" value="honey">
				<label for="ingredient28">1 ½ teaspoons honey</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient29" name="ingredient29" value="lemonjuice">
				<label for="ingredient29">1 ½ teaspoons lemon juice</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient30" name="ingredient30" value="cinnamonstick">
				<label for="ingredient30">1 cinnamon stick (Optional)</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient31" name="ingredient31" value="lemonzest">
				<label for="ingredient31">1 strip lemon zest (Optional)</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Combine tea, bourbon, honey, and lemon juice in a mug. Garnish with cinnamon stick and lemon zest, if desired.</li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Dairy-free, Egg Free, Gluten-free, Low Carbohydrate, Low Fat, Nut Free, Soy Free, Vegetarian</p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "500" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 1 cup</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>98 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>0.1 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>9.2 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>8.8 g</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>0.5 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>3.0 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>1.7 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>1.1 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>0.1 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>0.7 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>13.9 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>0.8 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn1" onclick="printContent('drink5')">Print Recipe</button></center><br><br>
			</div>
		</div>

		<div class="menurow">
			<div class="menucard1">
				<div id="drink6">
				<br><br><center><img src="Images/Drink 6.PNG" width="400px" alt=""></center><br><br>
				<center><h1>Spiced Hot Cider</h1></center><br>
				<center><h4>Total Time: 10 minutes</h4></center>
				<center><h4>Servings: 6</h4></center><br>
				<p>Nothing beats a mug of hot cider on a cold winter day. </p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient32" name="ingredient32" value="applecider">
				<label for="ingredient32">4 cups apple cider</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient33" name="ingredient33" value="cinnamonstick">
				<label for="ingredient33">1 cinnamon stick</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient34" name="ingredient34" value="cloves">
				<label for="ingredient34">5 whole cloves</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient35" name="ingredient35" value="cinnamon">
				<label for="ingredient35">2 tablespoons cinnamon-flavored syrup</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient36" name="ingredient36" value="cinnamonstick">
				<label for="ingredient36">Cinnamon sticks, for garnish</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Bring apple cider, cinnamon stick and cloves to a boil. Reduce heat and simmer for 5 minutes. Add applejack and schnapps. Garnish with a cinnamon stick and serve hot.</li><br>
				</ol>
				</p><br>
		

				<p><b>Perfect For:</b></p>
				<p>Low Fat, Dairy-free, Gluten-free, Vegan</p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "500" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 3/4 cup</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>143 kcal</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>23.2 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>22.5 g</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>2.3 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn2" onclick="printContent('drink6')">Print Recipe</button></center><br><br>
			</div>
		</div>
	</div>







<div class="footer">
  <h2>Contact Us</h2>
	<table style="width: 100%">
		<tr>
			<td style="width:50%">
				<p><b>The Kitchen Cooking Studio</b></p>
				<p>Address: <br>123, Jalan ABC, <br>Gateway Batu Pahat,<br>83000 Batu Pahat, Johor, Malaysia. </p>
				<p>Contact Number:<br>+607-123 4567</p>
				<a href= "About Us.php">FAQ</a><br>
				<a href="Event.php">More Events</a>
				<p>Website QR:</p>
				<img src="Images/qrcode.png" style="width:90px; height:120px;" alt=""/>
			</td>
			<td>
				<p>Factulty of Computer Science & Information technology <br> University Tun Hussein Onn Malaysia</p>
				<p>BIC 21203 Web Development<br>Group Project</p>
				<p>Lee Zi Hui (AI190244)<br>Liew Jia Yu (AI190235)<br>Sim Shin Ying (AI190231)<br>Tan Qian Ying (AI190236)</p>
			</td>
		</tr>
	</table>
	
</div>



<!--script for slideshow*/-->
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 5 seconds
}
</script>

<script>
function printContent(el){
		var restorepage = document.body.innerHTML;
		var printcontent = document.getElementById(el).innerHTML;
		document.body.innerHTML = printcontent;
		window.print();
		document.body.innerHTML = restorepage;
		}
</script>
	
</body>
</html>
