<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recipes-Salad</title>
	<link rel="stylesheet" href="stylesheet.css">
</head>

<body>
	
<div class="header">
<img src="Images/The Kitchen.png" style="width:25%" alt=""/>
<h1>The Kitchen Cooking Studio</h1>
</div>

<div class="navbar">
  <a href="Home.php">Home</a>
  <div class="dropdown">
    <button class="dropbtn">Recipes 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Recipe-Main Dishes.php">Main Dish</a>
      <a href="Recipe-Salad.php">Salad</a>
      <a href="Recipe-Healthy Drink.php">Drink</a>
    </div>
  </div>
  <a href="Event.php">Events &  Class</a>
  <a href="About Us.php">About Us</a>
</div>

<div class="card">
	<div class="slideshow-container">

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 1.png" style="width:100%" alt=""/>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 2.png" style="width:100%" alt=""/>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 3.png" style="width:100%" alt=""/>
	</div>

	</div>
	<br>

	<div style="text-align:center">
  		<span class="dot"></span> 
  		<span class="dot"></span> 
  		<span class="dot"></span> 
	</div>
    </div>


<!----All the recipe and images are taken from https://www.eatingwell.com/recipes/18421/low-calorie/main-dish/------>
	
	<div>
	<h1>Salad</h1>
		<div class="menurow">
			<div class="menucard">
				<div id="salad1">
				<br><br><center><img src="Images/Salad 1.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Buffalo Chicken Salad</h1></center><br>
				<center><h4>Total Time: 35 minutes</h4></center>
				<center><h4>Servings: 4</h4></center><br>
				<p>All the flavor of Buffalo chicken wings is packed into this irresistible, healthy salad. But unlike chicken wings, you can eat a big serving of this healthy Buffalo chicken salad recipe for just 291 calories.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient1" name="ingredient1" value="bluecheese">
				<label for="ingredient1">21/2 cup crumbled reduced-fat blue cheese plus 1/4 cup, divided</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient2" name="ingredient2" value="buttermilk">
				<label for="ingredient2">6 tablespoons buttermilk</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient3" name="ingredient3" value="redwinevinegar">
				<label for="ingredient3">4 teaspoons red-wine vinegar, divided</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient4" name="ingredient4" value="groundpepper">
				<label for="ingredient4">¼ teaspoon freshly ground pepper, divided </label><br>
				<input type="checkbox"  class="ingredient" id="ingredient5" name="ingredient5" value="chickenbreast">
				<label for="ingredient5">1 pound boneless, skinless chicken breast, cut into 3/4-inch pieces</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient6" name="ingredient6" value="flour">
				<label for="ingredient6">2 tablespoons all-purpose flour</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient7" name="ingredient7" value="virginoliveoil">
				<label for="ingredient7">1 tablespoon extra-virgin olive oil</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient8" name="ingredient8" value="hotsauce">
				<label for="ingredient8">2 tablespoons hot sauce, such as Frank&#8217;s Red Hot</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient9" name="ingredient9" value="romainelettuce">
				<label for="ingredient9">8 cups chopped romaine lettuce</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient10" name="ingredient10" value="largecarrot">
				<label for="ingredient10">3 large carrots, chopped</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient11" name="ingredient11" value="celery">
				<label for="ingredient11">3 large stalks celery, chopped</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient12" name="ingredient12" value="largecucumber">
				<label for="ingredient12">1 large cucumber, peeled, seeded and chopped</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Combine 1/2 cup blue cheese in a small bowl with buttermilk, 2 teaspoons vinegar and 1/8 teaspoon pepper; mix well, mashing slightly with a fork. Set aside.</li><br>
				<li>Place chicken in another bowl; sprinkle with flour and the remaining 1/8 teaspoon pepper and toss until coated.</li><br>
				<li>Heat oil in a large nonstick skillet over medium-high heat until very hot. Add the chicken and cook, turning occasionally, until just cooked through, 6 to 7 minutes. Stir in hot sauce and the remaining 2 teaspoons vinegar and cook, stirring often, until the chicken is coated, about 1 minute.</li><br>
				<li>Combine lettuce, carrots, celery and cucumber in a large bowl; add the reserved dressing and toss to coat. Divide the salad among 4 plates and top each with an equal portion of chicken and 1 tablespoon each of the reserved blue cheese.</li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Low-calories, Low Carbohydrate, Healthy Aging, Healthy Immunity, Low Added Sugars</p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 2 1/2 cups salad and 3 oz. chicken</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>291 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>31.6 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>15.0 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>4.7 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>6.1 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>10.8 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>4.1 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>75.0 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>1749.4 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>14.6 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>177.7 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>114.2 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>2.3 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>56.0 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>832.3 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>626.6 mg</td>
				</tr>
				<tr>
				<td>Thiamin</td>
				<td>0.2 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn1" onclick="printContent('salad1')">Print Recipe</button></center><br><br>
			</div>
		</div>
	
		<div class="menurow">
			<div class="menucard1">
				<div id="salad2">
				<br><br><center><img src="Images/Salad 2.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Shrimp, Avocado, and Egg Chopped Salad</h1></center><br>
				<center><h4>Total Time: 15 minutes</h4></center>
				<center><h4>Servings: 2</h4></center><br>
				<p>Peppery fresh radishes complement sweet shrimp and creamy avocado in this quick salad. Enjoy this healthy salad as a quick light dinner or for lunch.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient13" name="ingredient13" value="redonion">
				<label for="ingredient13">1/4 small red onion, thinly sliced</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient14" name="ingredient14" value="limejuice">
				<label for="ingredient14">2 tablespoon fresh lime juice</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient15" name="ingredient15" value="oliveoil">
				<label for="ingredient15">1 tablespoon olive oil</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient16" name="ingredient16" value="shrimp">
				<label for="ingredient16">12 oz. large peeled and deveined shrimp </label><br>
				<input type="checkbox"  class="ingredient" id="ingredient17" name="ingredient17" value="saltandpepper">
				<label for="ingredient17">Kosher salt and pepper</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient18" name="ingredient18" value="grapetomatoes">
				<label for="ingredient18">1 cup grape tomatoes, halved</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient19" name="ingredient19" value="butterlecttuce">
				<label for="ingredient19">8 cups butter lettuce</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient20" name="ingredient20" value="cilantroleaves">
				<label for="ingredient20">1/2 cup fresh cilantro leaves</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient21" name="ingredient21" value="avocado">
				<label for="ingredient21">1/2 avocado, diced</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient22" name="ingredient22" value="hardboiledeggs">
				<label for="ingredient22">2 hard boiled eggs, cut into pieces</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>In a large bowl, toss onion with lime juice and ½ tablespoon oil and let sit for 5 minutes.</li><br>
				<li>Heat  1/2 tablespoon oil in a large skillet on medium high. Season shrimp with 1/4 teaspoon each salt and pepper and cook until opaque throughout, 2 to 3 minutes per side.</li><br>
				<li>Toss tomatoes with onions, then toss with lettuce and cilantro. Divide among bowls and top with shrimp, avocado and egg. </li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Dairy-free, Gluten-free, Nut Free, Soy Free, High Protein, Omega-3 </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: about 3/4 cup shrimp salad and 2 cups greens</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>365 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>40.0 g</td>
				</tr>
				<tr>
				<td>Carbohydrate</td>
				<td>15.0 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>7.0 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>17.0 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>5.0 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>450.0 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>3428.0 IU</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>668.0 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>600.0 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn2" onclick="printContent('salad2')">Print Recipe</button></center><br><br>
			</div>
		</div>


		<div class="menurow">
			<div class="menucard">
				<div id="salad3">
				<br><br><center><img src="Images/Salad 3.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Chickpea Tuna Salad</h1></center><br>
				<center><h4>Total Time: 20 minutes</h4></center>
				<center><h4>Servings: 4</h4></center><br>
				<p>This chickpea tuna salad with capers, feta and cucumber makes for the perfect lunch to pack for work or school. You can prep the salad the night before (just be sure to keep the spinach separate and dress the salad right before serving).</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient23" name="ingredient23" value="lemonjuice">
				<label for="ingredient23">2 tablespoons lemon juice</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient24" name="ingredient24" value="nonpareilcapers">
				<label for="ingredient24">1 tablespoon nonpareil capers, rinsed and chopped</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient25" name="ingredient25" value="shallot">
				<label for="ingredient25">1 tablespoon finely chopped shallot</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient26" name="ingredient26" value="salt">
				<label for="ingredient26">¼ teaspoon salt</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient27" name="ingredient27" value="groudpepper">
				<label for="ingredient27">¼ teaspoon ground pepper</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient28" name="ingredient28" value="chickpeas">
				<label for="ingredient28">1 (15 ounce) can no-salt-added chickpeas, rinsed</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient29" name="ingredient29" value="oilpackedtuna">
				<label for="ingredient29">1 (6.7 ounce) jar oil-packed tuna, drained</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient30" name="ingredient30" value="cherrytomato">
				<label for="ingredient30">1 cup halved cherry tomatoes</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient31" name="ingredient31" value="englishcucumber">
				<label for="ingredient31">1 cup thinly sliced English cucumber</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient32" name="ingredient32" value="fetacheese">
				<label for="ingredient32">½ cup crumbled feta cheese</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient33" name="ingredient33" value="freshdill">
				<label for="ingredient33">2 tablespoons chopped fresh dill</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient34" name="ingredient34" value="oliveoil">
				<label for="ingredient34">3 tablespoons extra-virgin olive oil</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient35" name="ingredient35" value="babyspinach">
				<label for="ingredient35">3 cups baby spinach</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Stir lemon juice, capers, shallot, salt and pepper together in a large bowl. Let stand for 5 minutes.</li><br>
				<li>Meanwhile, toss chickpeas, tuna, tomatoes, cucumber, feta and dill together in a large bowl.</li><br>
				<li>Whisk oil into the lemon juice mixture until fully incorporated. Spoon about 5 tablespoons of the dressing into the chickpea mixture; toss to coat.</li><br>
				<li>Add spinach to the remaining dressing in the large bowl; toss to coat. Divide the spinach evenly among 4 plates; top each plate with 1 1/4 cups chickpea mixture. Serve immediately.</li>
				</ol>
				</p><br>
				
				<p><b>Tips:</b></p>
				<p><ul>
				<li>Prepare through Step 3 and refrigerate in an airtight container for up to 1 day.</li>
				</ul></p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Egg Free, Gluten-free, High Protein, Nut Free, Omega-3, Soy Free </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 3/4 cup spinach and 1 1/4 cups chickpea mixture</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>357 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>21.0 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>23.0 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>6.0 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>3.0 g</td>
				</tr>
				<tr>
				<td>Niacin  equivalents</td>
				<td>6.0 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>19.0 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>5.0 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>30.0 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>1869.0 IU</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>505.0 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn1" onclick="printContent('salad3')">Print Recipe</button></center><br><br>
			</div>
		</div>

		<div class="menurow">
			<div class="menucard1">
				<div id="salad4">
				<br><br><center><img src="Images/Salad 4.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Asian Tofu and Edamame Salad</h1></center><br>
				<center><h4>Total Time: 10 minutes</h4></center>
				<center><h4>Servings: 1</h4></center><br>
				<p>Craving crunch? Bite into this salad loaded with crisp red cabbage, edamame, bamboo shoots, and chow mein noodles. This salad is slightly sweetened with baked tofu, mandarin oranges, and Asian sesame vinaigrette.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient36" name="ingredient36" value="mesclun">
				<label for="ingredient36">4 cups mesclun</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient37" name="ingredient37" value="redcabbage">
				<label for="ingredient37">½ cup shredded red cabbage</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient38" name="ingredient38" value="tofucubes">
				<label for="ingredient38">3 ounces baked tofu cubes</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient39" name="ingredient39" value="gratedcarrot">
				<label for="ingredient39">½ cup grated carrots</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient40" name="ingredient40" value="edamame">
				<label for="ingredient40">½ cup edamame</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient41" name="ingredient41" value="mandrainorange">
				<label for="ingredient41">¼ cup mandarin oranges</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient42" name="ingredient42" value="goldenraisin">
				<label for="ingredient42">1 tablespoon golden raisins</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient43" name="ingredient43" value="bambooshoot">
				<label for="ingredient43">½ cup bamboo shoots</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient44" name="ingredient44" value="chowmein">
				<label for="ingredient44">2 tablespoons chow mein noodles</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient45" name="ingredient45" value="sesame">
				<label for="ingredient45">2 tablespoons bottled reduced-sugar Asian sesame vinaigrette</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Mix mesclun, cabbage, tofu, carrots, edamame, oranges, raisins, bamboo shoots, and chow mein noodles in a medium bowl. Drizzle with vinaigrette.</li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Heart Healthy, Vegetarian, Vegan, Diabetes Appropriate, Egg Free, Healthy Aging, High Protein, Low Sodium, Low-calories, Dairy-free, Nut Free </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 1 salad</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>368 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>19.5 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>43.5 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>11.5 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>19.0 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>11.5 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>0.5 g</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>469.0 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn2" onclick="printContent('salad4')">Print Recipe</button></center><br><br>
			</div>
		</div>
	
	<div class="menurow">
			<div class="menucard">
				<div id="salad5">
				<br><br><center><img src="Images/Salad 5.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Fresh Fruit Salad</h1></center><br>
				<center><h4>Total Time: 15 minutes</h4></center>
				<center><h4>Servings: 10</h4></center><br>
				<p>This refreshing fruit salad is a classic combination that will be the favorite at any potluck or cookout. Serve with a creamy yogurt dressing to take this side (or dessert) to the next level.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient46" name="ingredient46" value="pineapple">
				<label for="ingredient46">2 cups diced fresh pineapple</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient47" name="ingredient47" value="strawberry">
				<label for="ingredient47">1 pound strawberries, hulled and sliced</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient48" name="ingredient48" value="blackberry">
				<label for="ingredient48">½ pint blackberries, halved</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient49" name="ingredient49" value="kiwi">
				<label for="ingredient49">4 ripe kiwis, peeled, halved and sliced</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient50" name="ingredient50" value="yougurt">
				<label for="ingredient50">1 cup Lime Yogurt Fruit Salad Dressing (optional)</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Combine pineapple, strawberries, blackberries and kiwi in a large bowl. Serve with yogurt dressing, if desired.</li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Heart Healthy, Low Carbohydrate, Low-calories, Low Fat, Low Sodium, High Fiber, Diabetes Appropriate, Gluten-free, Vegetarian, Vegan, Nut Free, Soy Free </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 3/4 cup</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>57 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>1.0 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>13.9 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>3.0 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>9.1 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>0.4 g</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>82.5 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>73.6 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>28.3 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>25.8 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>0.5 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>18.1 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>220.6 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>1.8 mg</td>
				</tr>
				<tr>
				<td>Thiamin</td>
				<td>0.1 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn1" onclick="printContent('salad5')">Print Recipe</button></center><br><br>
			</div>
		</div>

		<div class="menurow">
			<div class="menucard1">
				<div id="salad6">
				<br><br><center><img src="Images/Salad 6.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Chicken Caesar Pasta Salad</h1></center><br>
				<center><h4>Total Time: 30 minutes</h4></center>
				<center><h4>Servings: 6</h4></center><br>
				<p>This scrumptious and healthy salad combines elements of Caesar salad, pasta salad and chicken salad for an easy weeknight dinner that comes together in less than 30 minutes (and most of the prep can be done ahead). Use your blender to whip together the tangy buttermilk-based dressing, which would also be great on a salmon or chickpea salad.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient51" name="ingredient51" value="greekyogurt">
				<label for="ingredient51">¼ cup low-fat plain Greek yogurt</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient52" name="ingredient52" value="virginoliveoil">
				<label for="ingredient52">3 tablespoons extra-virgin olive oil</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient53" name="ingredient53" value="lemonjuice">
				<label for="ingredient53">2 tablespoons fresh lemon juice</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient54" name="ingredient54" value="dijonmustard">
				<label for="ingredient54">2 teaspoons Dijon mustard</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient55" name="ingredient55" value="anchovypaste">
				<label for="ingredient55">1 ½ teaspoons anchovy paste</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient56" name="ingredient56" value="garlic clove">
				<label for="ingredient56">1 large garlic clove</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient57" name="ingredient57" value="parmesan">
				<label for="ingredient57">¾ cup finely grated Parmesan cheese, divided</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient58" name="ingredient58" value="salt">
				<label for="ingredient58">½ teaspoon salt, divided</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient59" name="ingredient59" value="groundpepper">
				<label for="ingredient59">½ teaspoon ground pepper, divided</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient60" name="ingredient60" value="penne">
				<label for="ingredient60">8 ounces whole-wheat penne</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient61" name="ingredient61" value="cookedchicken">
				<label for="ingredient61">3 cups shredded cooked chicken breast</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient62" name="ingredient62" value="tomato">
				<label for="ingredient62">1 pint cherry tomatoes, halved</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient63" name="ingredient63" value="lettuce">
				<label for="ingredient63">5 cups chopped romaine lettuce</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Combine buttermilk, yogurt, oil, lemon juice, mustard, anchovy paste, garlic, 1/2 cup Parmesan and 1/4 teaspoon each salt and pepper in a blender; puree on high speed until smooth, about 1 minute. Set aside.</li><br>
				<li>Cook pasta according to package directions, omitting salt. Drain, reserving 1 cup cooking water.</li><br>
				<li>Combine the pasta, chicken, tomatoes, 1/4 cup of the reserved cooking water and the remaining 1/4 teaspoon each salt and pepper in a large bowl. Stir in the buttermilk dressing until thoroughly combined. Stir in additional cooking water as needed for a creamy consistency. Cover and chill for at least 30 minutes or up to 2 days.</li><br>
				<li>Just before serving, stir in lettuce; sprinkle with the remaining 1/4 cup Parmesan.</li><br>
				</ol>
				</p><br>
				
				<p><b>Tips:</b>
				<ul>
				<li>Prepare through Step 3 and refrigerate for up to 2 days.</li><br>
				</ul>
				</p>
				
		
				<p><b>Perfect For:</b></p>
				<p>Diabetes Appropriate, Healthy Aging, Healthy Immunity, Heart Healthy, Low Sodium, Low-calories, Nut Free, Soy Fress, Egg Free</p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 1 1/2 cups</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>383 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>32.8 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>33.8 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>4.4 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>4.0 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>13.6 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>3.7 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>71.9 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>3980.3 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>9.5 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>71.8 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>171.8 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>2.5 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>69.4 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>507.5 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>571.8 mg</td>
				</tr>
				<tr>
				<td>Thiamin</td>
				<td>0.2 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn2" onclick="printContent('salad6')">Print Recipe</button></center><br><br>
			</div>
		</div>
	</div>







<div class="footer">
<h2>Contact Us</h2>
	<table style="width: 100%">
		<tr>
			<td style="width:50%">
			<p><b>The Kitchen Cooking Studio</b></p>
				<p>Address: 123, Jalan ABC, Gateway Batu Pahat,<br>83000 Batu Pahat, Johor, Malaysia. </p>
				<p>Contact Number: +607-123 4567</p>
				<a href= "About Us.php">FAQ</a><br>
				<a href="Event.php">More Events</a>
				<p>Website QR:</p>
				<img src="Images/qrcode.png" style="width:90px; height:120px;" alt=""/>
			</td>
			<td>
				<p>Factulty of Computer Science & Information technology<br>University Tun Hussein Onn Malaysia</p>
				<p>BIC 21203 Web Development<br>Project</p>
				<p>Lee Zi Hui (AI190244)<br>Liew Jia Yu (AI190235)<br>Sim Shin Ying (AI190231)<br>Tan Qian Ying (AI190236)</p>
			</td>
		</tr>
	</table>
</div>



<!--script for slideshow*/-->
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 5 seconds
}
</script>

<script>
function printContent(el){
		var restorepage = document.body.innerHTML;
		var printcontent = document.getElementById(el).innerHTML;
		document.body.innerHTML = printcontent;
		window.print();
		document.body.innerHTML = restorepage;
		}
</script>
	
</body>
</html>
