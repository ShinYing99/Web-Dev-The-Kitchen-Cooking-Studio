<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recipes-Main Dishes</title>
	<link rel="stylesheet" href="stylesheet.css">
</head>
<body>
<div class="hero-image">
<div class="header">
<img src="Images/The Kitchen.png" style="width:25%" alt=""/>
<h1>The Kitchen Cooking Studio</h1>
</div>

<div class="navbar">
  <a href="Home.php">Home</a>
  <div class="dropdown">
    <button class="dropbtn">Recipes 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Recipe-Main Dishes.php">Main Dish</a>
      <a href="Recipe-Salad.php">Salad</a>
      <a href="Recipe-Healthy Drink.php">Drink</a>
    </div>
  </div>
  <a href="Event.php">Events &  Class</a>
  <a href="About Us.php">About Us</a>
</div>

<div class="card">
	<div class="slideshow-container">

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 1.png" style="width:100%" alt=""/>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 2.png" style="width:100%" alt=""/>
	</div>

	<div class="mySlides fade">
  	<div class="numbertext"></div>
  	<img src="Images/Healthy 3.png" style="width:100%" alt=""/>
	</div>

	</div>
	<br>

	<div style="text-align:center">
  		<span class="dot"></span> 
  		<span class="dot"></span> 
  		<span class="dot"></span> 
	</div>
    </div>


<!----All the recipe and images are taken from https://www.eatingwell.com/recipes/18421/low-calorie/main-dish/------>
	
	<div>
	<h1>Mian Dishes</h1>


		<div class="menurow">
			<div class="menucard">
				<div id="main1">
				<br><br><center><img src="Images/Main Dish 1.PNG" width="300px" alt=""></center><br><br>
				<center><h1>One-Pot Greek Pasta</h1></center><br>
				<center><h4>Total Time: 20 minutes</h4></center>
				<center><h4>Servings: 4</h4></center><br>
				<p>A little bit of Sunday meal prep goes a long way in this one-dish Mediterranean pasta recipe. The pasta is cooked ahead of time and stored in the fridge to use for meals all week, but any leftover cooked pasta you have on hand will do. Chicken sausage with feta is especially good in this recipe.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient1" name="ingredient1" value="oil">
				<label for="ingredient1">2 tablespoon olive oil</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient2" name="ingredient2" value="sausage">
				<label for="ingredient2">3 links cooked chicken sausage (9 ounces), sliced into rounds</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient3" name="ingredient3" value="onion">
				<label for="ingredient3">1 cup diced onion </label><br>
				<input type="checkbox"  class="ingredient" id="ingredient4" name="ingredient4" value="garlic">
				<label for="ingredient4">1 clove garlic, minced </label><br>
				<input type="checkbox"  class="ingredient" id="ingredient5" name="ingredient5" value="sauce">
				<label for="ingredient5">1 (8 ounce) can no-salt-added tomato sauce</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient6" name="ingredient6" value="spinach">
				<label for="ingredient6">4 cups lightly packed baby spinach (half of a 5-ounce box)</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient7" name="ingredient7" value="pasta">
				<label for="ingredient7">6 cups cooked whole-wheat rotini pasta</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient8" name="ingredient8" value="olive">
				<label for="ingredient8">¼ cup chopped pitted Kalamata olives</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient9" name="ingredient9" value="cheese">
				<label for="ingredient9">½ cup finely crumbled feta cheese</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient10" name="ingredient10" value="basil">
				<label for="ingredient10">¼ cup chopped fresh basil (Optional)</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Cook Whole-Wheat Rotini Pasta. Put a big pot of water on to boil for a 1-pound box of pasta.</li><br>
				<li>Heat oil in a large straight-sided skillet over medium-high heat.</li><br>
				<li>Add sausage, onion and garlic; cook, stirring often, until the onion is starting to brown, 4 to 6 minutes.</li><br>
				<li>Add tomato sauce, spinach, pasta and olives; cook, stirring often, until bubbling hot and the spinach is wilted, 3 to 5 minutes.</li><br>
				<li>Add 1 to 2 tablespoons water, if necessary, to keep the pasta from sticking. </li><br>
				<li> Stir in feta and basil, if using.</li>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Egg Free, Healthy Aging, Healthy Immunity, Healthy Pregnancy, High Protein, Low-calories, Nut Free, Soy Free </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 2 cups</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>487 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>22.8 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>59.3 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>8.1 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>6.7 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>16.9 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>4.2 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>61.7 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>1290.6 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>10.3 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>72.2 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>142.3 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>3.8 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>111.5 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>464.8 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>623.3 mg</td>
				</tr>
				<tr>
				<td>Thiamin</td>
				<td>0.3 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn1" onclick="printContent('main1')">Print Recipe</button></center><br><br>
			</div>
		</div>
	

	
		<div class="menurow">
			<div class="menucard1">
				<div id="main2">
				<br><br><center><img src="Images/Main Dish 2.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Herb-Roasted Turkey</h1></center><br>
				<center><h4>Total Time: 3 hours 30 minutes</h4></center>
				<center><h4>Servings: 12</h4></center><br>
				<p>This easy method produces all the good looks and moist flavor you dream of in an oven-roasted turkey. Make sure you show this beauty off at the table before you carve it. Garnish your serving platter with fresh herb sprigs and citrus wedges.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient11" name="ingredient11" value="turkey">
				<label for="ingredient11">1 10- to 12-pound turkey</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient12" name="ingredient12" value="herb">
				<label for="ingredient12">¼ cup fresh herbs, plus 20 whole sprigs, such as thyme, rosemary, sage, oregano and/or marjoram, divided</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient13" name="ingredient13" value="canola">
				<label for="ingredient13">2 tablespoons canola oil</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient14" name="ingredient14" value="salt">
				<label for="ingredient14">1 teaspoon salt </label><br>
				<input type="checkbox"  class="ingredient" id="ingredient15" name="ingredient15" value="pepper">
				<label for="ingredient15">1 teaspoon freshly ground pepper</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient16" name="ingredient16" value="apple">
				<label for="ingredient16">Aromatics, onion, apple, lemon and/or orange, cut into 2-inch pieces (1 1/2 cups)</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient17" name="ingredient17" value="water">
				<label for="ingredient17">3 cups water, plus more as needed</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Position a rack in the lower third of the oven; preheat to 475 degrees F.</li><br>
				<li>Remove giblets and neck from turkey cavities and reserve for making gravy. Place the turkey, breast-side up, on a rack in a large roasting pan; pat dry with paper towels. Mix minced herbs, oil, salt and pepper in a small bowl. Rub the herb mixture all over the turkey, under the skin and onto the breast meat. Place aromatics and 10 of the herb sprigs in the cavity. Tuck the wing tips under the turkey. Tie the legs together with kitchen string. Add 3 cups water and the remaining 10 herb sprigs to the pan.</li><br>
				<li>Roast the turkey until the skin is golden brown, 45 minutes. Remove from the oven. Cover the breast with a double layer of foil, cutting as necessary to conform to the breast. </li><br>
				<li>Reduce oven temperature to 350° and continue roasting until an instant-read thermometer inserted into the thickest part of a thigh without touching bone registers 165°, 1 1/4 to 1 3/4 hours more. If the pan dries out, tilt the turkey to let juices run out of the cavity into the pan and add 1 cup water. </li><br>
				<li>Transfer the turkey to a serving platter and cover with foil.Let the turkey rest for 20 minutes. Remove string and carve. </li>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Dairy-free, Diabetes Appropriate, Gluten-free, Healthy Aging, Heart Healthy, High-protein, Low Added Sugars, Low Carbohydrate, Low Sodium, Low-calories </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 3 ounces</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>172 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>25.0 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>7.0 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>2.0 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>88.0 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>271.0 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>0.3 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>8.0 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>13 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>27.0 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>210.0 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>320.0 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn2" onclick="printContent('main2')">Print Recipe</button></center><br><br>
			</div>
		</div>


		<div class="menurow">
			<div class="menucard">
				<div id="main3">
				<br><br><center><img src="Images/Main Dish 3.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Turkey Tomatillo Burgers</h1></center><br>
				<center><h4>Total Time: 35 minutes</h4></center>
				<center><h4>Servings: 2</h4></center><br>
				<p>Beautiful green slices of tomatillo and melted Muenster cheese sit atop these grilled turkey burgers. A teaspoon of chopped chipotle peppers is added to the ground turkey mixture, providing just a touch of heat to these mouthwatering burgers.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient18" name="ingredient18" value="eggwhite">
				<label for="ingredient18">1 large egg white, slightly beaten</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient19" name="ingredient19" value="breadcrumb">
				<label for="ingredient19">2 tablespoons fine dry breadcrumbs</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient20" name="ingredient20" value="cilantro">
				<label for="ingredient20">1 tablespoon chopped fresh cilantro</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient21" name="ingredient21" value="chilepepper">
				<label for="ingredient21">1 teaspoon chopped canned chipotle chile pepper in adobo sauce (see Tip) </label><br>
				<input type="checkbox"  class="ingredient" id="ingredient22" name="ingredient22" value="colvedgarlic">
				<label for="ingredient22">1 clove garlic, minced</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient23" name="ingredient23" value="chilipowder">
				<label for="ingredient23">¼ teaspoon chili powder</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient24" name="ingredient24" value="groundpepper">
				<label for="ingredient24">⅛ teaspoon freshly ground pepper</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient25" name="ingredient25" value="turkeybreast">
				<label for="ingredient25">8 ounces uncooked ground turkey breast</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient26" name="ingredient26" value="tomato">
				<label for="ingredient26">4 slices tomatillo and/or tomato</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient27" name="ingredient27" value="muenstercheese">
				<label for="ingredient27">2 slices Muenster cheese</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient28" name="ingredient28" value="bread">
				<label for="ingredient28">2 whole-wheat hamburger buns, split and toasted</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Combine egg white, breadcrumbs, cilantro, chipotle pepper in adobo sauce, garlic, chili powder and ground pepper in a medium bowl. Add ground turkey breast; mix well. Using your clean hands, shape turkey mixture into two 3/4-inch-thick patties. (If mixture is sticky, moisten hands with water.)</li><br>
				<li>For a charcoal grill, grill burgers on the lightly greased rack of an uncovered grill directly over medium coals for 14 to 18 minutes or until no longer pink (165 degrees F; see Tip), turning once halfway through grilling; add tomatillo and/or tomato slices to the grill and top each burger with a slice of cheese for the last 2 minutes of grilling. (For a gas grill, preheat grill. Reduce heat to medium. Place burgers and later tomatillos and/or tomato slices, on grill rack over heat. Cover and grill as above.)</li><br>
				<li>Serve grilled turkey burgers topped with tomatillo and/or tomato slices in buns.</li>
				</ol>
				</p><br>
				
				<p><b>Tips:</b></p>
				<p><ul>
				<li>Because chile peppers contain volatile oils that can burn your skin and eyes, avoid direct contact with them as much as possible. When working with chile peppers, wear plastic or rubber gloves. If your bare hands do touch the peppers, wash your hands and nails well with soap and warm water.</li><br>
				<li>The internal color of a burger is not a reliable doneness indicator. A turkey patty cooked to 165 degrees F is safe, regardless of color. To measure the doneness of a patty, insert a thermometer through the side of the patty to a depth of 2 to 3 inches.</li>
				</ul></p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Bone Health, Diabetes Appropriate, Healthy Aging, Heart Healthy, High Calcium, High-protein, Low Sodium, Low-calories, Nut Free, Soy Free </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 1 burger</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>360 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>39.9 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>28.3 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>3.0 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>5.5 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>8.8 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>4.4 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>90.7 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>516.5 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>5.2 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>27.8 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>285.3 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>3.2 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>47.7 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>470.8 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>492.4 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn1" onclick="printContent('main3')">Print Recipe</button></center><br><br>
			</div>
		</div>

		<div class="menurow">
			<div class="menucard1">
				<div id="main4">
				<br><br><center><img src="Images/Main Dish 4.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Salmon with Asparagus and Mushrooms</h1></center><br>
				<center><h4>Total Time: 45 minutes</h4></center>
				<center><h4>Servings: 4</h4></center><br>
				<p>Mushrooms and salmon are both naturally high in vitamin D, so you get a double dose in this 45-minute dinner recipe.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient29" name="ingredient29" value="salmon">
				<label for="ingredient29">4 fresh or frozen skinless salmon fillets, about 1 inch thick (about 1 pound total)</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient30" name="ingredient30" value="koshersalt">
				<label for="ingredient30">Kosher salt</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient31" name="ingredient31" value="groundpepper">
				<label for="ingredient31">Freshly ground pepper </label><br>
				<input type="checkbox"  class="ingredient" id="ingredient32" name="ingredient32" value="oliveoil">
				<label for="ingredient32">2 tablespoons olive oil</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient33" name="ingredient33" value="mushroom">
				<label for="ingredient33">2 cups sliced assorted fresh mushrooms (such as button, cremini, and/or stemmed shiitake)</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient34" name="ingredient34" value="onion">
				<label for="ingredient34">1 cup chopped onion</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient35" name="ingredient35" value="garlic">
				<label for="ingredient35">6 cloves garlic, minced (1 tablespoon minced)</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient36" name="ingredient36" value="thyme">
				<label for="ingredient36">1 tablespoon chopped fresh thyme</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient37" name="ingredient37" value="wine">
				<label for="ingredient37">1 cup dry white wine</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient38" name="ingredient38" value="juice">
				<label for="ingredient38">1 cup clam juice, fish stock, chicken stock, or chicken broth</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient39" name="ingredient39" value="asparagus">
				<label for="ingredient39">2 cups (1 1/2 inch) pieces asparagus</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient40" name="ingredient40" value="cherrytomato">
				<label for="ingredient40">1 cup cherry tomatoes, halved</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient41" name="ingredient41" value="parsley">
				<label for="ingredient41">1 tablespoon chopped fresh Italian parsley</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient42" name="ingredient42" value="lemonjuice">
				<label for="ingredient42">1 teaspoon lemon juice</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient43" name="ingredient43" value="thyme">
				<label for="ingredient43">1 teaspoon Fresh thyme sprigs</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Thaw fish, if frozen. Rinse fish; pat dry with paper towels. Measure thickness of fish fillets. Season fish with salt and pepper; set aside</li><br>
				<li>Heat 1 tablespoon of the olive oil in a large skillet over medium heat. Add mushrooms; cook about 5 minutes or until golden brown. Add onion, garlic, and thyme; cook until mushrooms are tender, stirring occasionally. Add wine. Bring to boiling; reduce heat. Simmer, uncovered, about 15 minutes or until liquid is reduced to 1/4 cup</li><br>
				<li>Add clam juice. Return to boiling; reduce heat. Simmer, uncovered, about 15 minutes more or until liquid is reduced to 3/4 cup. Add the asparagus. Cover and cook about 3 minutes or until asparagus is crisp-tender. Stir in tomatoes, parsley, and lemon juice. Season to taste with salt and pepper. Transfer to a serving platter and keep warm.</li><br>
				<li>In the same skillet, heat the remaining 1 tablespoon olive oil over medium heat. Add salmon; cook for 4 to 6 minutes per 1/2-inch thickness of salmon or until salmon flakes easily when tested with a fork, turning once. Serve salmon over vegetable mixture. If desired, garnish with fresh thyme.</li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Egg Free, Healthy Aging, Healthy Immunity, Healthy Pregnancy, High Protein, Low-calories, Nut Free, Soy Free </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 1 serving</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>372 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>30.8 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>13.0 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>3.3 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>5.6 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>19.5 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>3.5 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>66.9 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>1045.7 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>22.1 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>88.8 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>62.5 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>5.6 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>63.0 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>934.2 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>624.3 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn2" onclick="printContent('main4')">Print Recipe</button></center><br><br>
			</div>
		</div>
	
	<div class="menurow">
			<div class="menucard">
				<div id="main5">
				<br><br><center><img src="Images/Main Dish 5.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Slow-Cooker Braised Beef with Carrots and Turnips</h1></center><br>
				<center><h4>Total Time: 4 hours</h4></center>
				<center><h4>Servings: 8</h4></center><br>
				<p>The spice blend in this healthy beef stew recipe--cinnamon, allspice and cloves--may conjure images of apple pie, but the combo is a great fit in savory applications too. Serve over creamy polenta or buttered whole-wheat egg noodles.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient44" name="ingredient44" value="koshersalt">
				<label for="ingredient44">1 tablespoon kosher salt</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient45" name="ingredient45" value="cinnamon">
				<label for="ingredient45">2 teaspoons ground cinnamon</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient46" name="ingredient46" value="allspice">
				<label for="ingredient46">½ teaspoon ground allspice </label><br>
				<input type="checkbox"  class="ingredient" id="ingredient47" name="ingredient47" value="groundpepper">
				<label for="ingredient47">½ teaspoon ground pepper</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient48" name="ingredient48" value="cloves">
				<label for="ingredient48">¼ teaspoon ground cloves</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient49" name="ingredient49" value="beef">
				<label for="ingredient49">3-3 1/2 pounds beef chuck roast, trimmed</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient50" name="ingredient50" value="oliveoil">
				<label for="ingredient50">2 tablespoons extra-virgin olive oil</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient51" name="ingredient51" value="mediumonion">
				<label for="ingredient51">1 medium onion, chopped</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient52" name="ingredient52" value="clovesgarlic">
				<label for="ingredient52">3 cloves garlic, sliced</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient53" name="ingredient53" value="redwine">
				<label for="ingredient53">1 cup red wine</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient54" name="ingredient54" value="wholetomato">
				<label for="ingredient54">1 (28 ounce) can whole tomatoes, preferably San Marzano</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient55" name="ingredient55" value="carrot">
				<label for="ingredient55">5 medium carrots, cut into 1-inch pieces</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient56" name="ingredient56" value="turnip">
				<label for="ingredient56">2 medium turnips, peeled and cut into 1/2-inch pieces</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient57" name="ingredient57" value="freshbasil">
				<label for="ingredient57">Chopped fresh basil for garnish</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Combine salt, cinnamon, allspice, pepper and cloves in a small bowl. Rub the mixture all over beef.</li><br>
				<li>Heat oil in a large skillet over medium heat. Add the beef and cook until browned, 4 to 5 minutes per side. Transfer to a 5- to 6-quart slow cooker.</li><br>
				<li>Add onion and garlic to the pan. Cook, stirring, for 2 minutes. Add wine and tomatoes (with their juice); bring to a boil, scraping up any browned bits and breaking up the tomatoes. Add the mixture to the slow cooker along with carrots and turnips.</li><br>
				<li>Cover and cook on High for 4 hours or Low for 8 hours.</li><br>
				<li>Remove the beef from the slow cooker and slice. Serve the beef with the sauce and vegetables, garnished with basil, if desired.</li><br>
				</ol>
				</p><br>
		
				<p><b>Perfect For:</b></p>
				<p>Dairy-free, Diabetes Appropriate, Egg Free, Gluten-free, Healthy Aging, Healthy Immunity, Healthy Pregnancy, Heart Healthy, High Protein, Low Added Sugars, Low Carbohydrate, Low Sodium, Low-calories, Nut Free, Soy Free </p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: 3 oz. beef and 1 cup vegetables each</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>318 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>34.7 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>12.8 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>3.1 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>6.2 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>10.7 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>3.2 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>98.9 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>6776.9 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>17.4 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>26.3 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>69.0 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>3.5 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>36.0 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>697.7 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>538.4 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn1" onclick="printContent('main5')">Print Recipe</button></center><br><br>
			</div>
		</div>

		<div class="menurow">
			<div class="menucard1">
				<div id="main6">
				<br><br><center><img src="Images/Main Dish 6.PNG" width="300px" alt=""></center><br><br>
				<center><h1>Cream of Turkey and Wild Rice Soup</h1></center><br>
				<center><h4>Total Time: 35 minutes</h4></center>
				<center><h4>Servings: 4</h4></center><br>
				<p>Got leftover cooked chicken or turkey? Cook up a pot of soup! This recipe is a healthier twist on a classic creamy turkey and wild rice soup that hails from Minnesota. Serve with a crisp romaine salad and whole-grain bread.</p><br>
				<p><b>Ingredients:</b>
				<ul>
				<input type="checkbox" class="ingredient" id="ingredient58" name="ingredient58" value="virginoliveoil">
				<label for="ingredient58">1 tablespoon extra-virgin olive oil</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient59" name="ingredient59" value="slicedmushroom">
				<label for="ingredient59">2 cups sliced mushrooms, (about 4 ounces)</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient60" name="ingredient60" value="celery">
				<label for="ingredient60">¾ cup chopped celery </label><br>
				<input type="checkbox"  class="ingredient" id="ingredient61" name="ingredient61" value="choppedcarrot">
				<label for="ingredient61">¾ cup chopped carrots</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient62" name="ingredient62" value="shallots">
				<label for="ingredient62">¼ cup chopped shallots</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient63" name="ingredient63" value="flour">
				<label for="ingredient63">¼ cup all-purpose flour</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient64" name="ingredient64" value="salts">
				<label for="ingredient64">¼ teaspoon salt</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient65" name="ingredient65" value="groundpepper">
				<label for="ingredient65">¼ teaspoon freshly ground pepper</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient66" name="ingredient66" value="chickenbroth">
				<label for="ingredient66">4 cups reduced-sodium chicken broth</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient67" name="ingredient67" value="wildrice">
				<label for="ingredient67">1 cup quick-cooking or instant wild rice</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient68" name="ingredient68" value="cookedchicken">
				<label for="ingredient68">3 cups shredded cooked chicken, or turkey (12 ounces; see Tip)</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient69" name="ingredient69" value="sourcream">
				<label for="ingredient69">½ cup reduced-fat sour cream</label><br>
				<input type="checkbox"  class="ingredient" id="ingredient70" name="ingredient70" value="choppedparsley">
				<label for="ingredient70">2 tablespoons chopped fresh parsley</label><br>
				</ul>
				</p><br>
			
				<p><b>Steps:</b>
				<ol>
				<li>Heat oil in a large saucepan over medium heat. Add mushrooms, celery, carrots and shallots and cook, stirring, until softened, about 5 minutes. Add flour, salt and pepper and cook, stirring, for 2 minutes more.</li><br>
				<li>Add broth and bring to a boil, scraping up any browned bits. Add rice and reduce heat to a simmer. Cover and cook until the rice is tender, 5 to 7 minutes. Stir in turkey (or chicken), sour cream and parsley and cook until heated through, about 2 minutes more.</li><br>
				</ol>
				</p><br>
				
				<p><b>Tips:</b>
				<ul>
				<li>Quick-cooking or instant wild rice has been parboiled to reduce the cooking time. Conventional wild rice takes 40 to 50 minutes to cook. Be sure to check the cooking directions when selecting your rice--some brands labeled “quick” take about 30 minutes to cook. If you can't find the quick-cooking variety, just add cooked conventional wild rice along with the turkey at the end of Step 2.</li><br>
				<li>To poach chicken breasts, place boneless, skinless chicken breasts in a medium skillet or saucepan. Add lightly salted water to cover and bring to a boil. Cover, reduce heat to low and simmer gently until chicken is cooked through and no longer pink in the middle, 10 to 12 minutes.</li>
				</ul>
				</p><br>
				
		
				<p><b>Perfect For:</b></p>
				<p>Diabetes Appropriate, Healthy Aging, Healthy Immunity, Heart Healthy, High Blood Pressure, High Protein, Low Added Sugars, Low Sodium, Low-calories</p><br>
		
				<p><b>Nutrition Facts:</b></p><br>
				<table border = "1" width = "300px" align = "center" bgcolor = "white">
				<tr>
				<td colspan="2"><b>Serving size: about 1 3/4 cups</b></td>
				</tr>
				<tr>
				<td colspan="2"><b>Per Serving:</b></td>
				</tr>
				<tr>
				<td>Calories</td>
				<td>378 kcal</td>
				</tr>
				<tr>
				<td>Protein</td>
				<td>36.9 g</td>
				</tr>
				<tr>
				<td>Carbohydrates</td>
				<td>28.5 g</td>
				</tr>
				<tr>
				<td>Dietary fiber</td>
				<td>2.7 g</td>
				</tr>
				<tr>
				<td>Sugars</td>
				<td>2.8 g</td>
				</tr>
				<tr>
				<td>Fat</td>
				<td>10.6 g</td>
				</tr>
				<tr>
				<td>Saturated fat</td>
				<td>3.7 g</td>
				</tr>
				<tr>
				<td>Cholesterol</td>
				<td>79.7 mg</td>
				</tr>
				<tr>
				<td>Vitamin A</td>
				<td>4518.3 IU</td>
				</tr>
				<tr>
				<td>Vitamin C</td>
				<td>6.3 mg</td>
				</tr>
				<tr>
				<td>Folate</td>
				<td>57.3 mcg</td>
				</tr>
				<tr>
				<td>Calcium</td>
				<td>73.2 mg</td>
				</tr>
				<tr>
				<td>Iron</td>
				<td>2.4 mg</td>
				</tr>
				<tr>
				<td>Magnesium</td>
				<td>45.7 mg</td>
				</tr>
				<tr>
				<td>Potassium</td>
				<td>748.3 mg</td>
				</tr>
				<tr>
				<td>Sodium</td>
				<td>364.1 mg</td>
				</tr>
				<tr>
				<td>Thiamin</td>
				<td>0.2 mg</td>
				</tr>
				</table><br><br>
				</div>
				<center><button class ="btn2" onclick="printContent('main6')">Print Recipe</button></center><br><br>
			</div>
		</div>
	</div>
</div>





<div class="footer">
<h2>Contact Us</h2>
	<table style="width: 100%">
		<tr>
			<td style="width:50%">
			<p><b>The Kitchen Cooking Studio</b></p>
				<p>Address: 123, Jalan ABC, Gateway Batu Pahat,<br>83000 Batu Pahat, Johor, Malaysia. </p>
				<p>Contact Number: +607-123 4567</p>
				<a href="About Us.php">FAQ</a><br>
				<a href="Event.php">More Events</a>
				 <p>Website QR:</p>
				<img src="Images/qrcode.png" style="width:90px; height:120px;" alt=""/>
			</td>
			<td>
				<p>Factulty of Computer Science & Information technology<br>University Tun Hussein Onn Malaysia</p>
				<p>BIC 21203 Web Development<br>Project</p>
				<p>Lee Zi Hui (AI190244)<br>Liew Jia Yu (AI190235)<br>Sim Shin Ying (AI190231)<br>Tan Qian Ying (AI190236)</p>
			</td>
		</tr>
	</table>
	
</div>



<!--script for slideshow*/-->
<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 5000); // Change image every 5 seconds
}
</script>

<script>
function printContent(el){
		var restorepage = document.body.innerHTML;
		var printcontent = document.getElementById(el).innerHTML;
		document.body.innerHTML = printcontent;
		window.print();
		document.body.innerHTML = restorepage;
		}
</script>
	
</body>
</html>
